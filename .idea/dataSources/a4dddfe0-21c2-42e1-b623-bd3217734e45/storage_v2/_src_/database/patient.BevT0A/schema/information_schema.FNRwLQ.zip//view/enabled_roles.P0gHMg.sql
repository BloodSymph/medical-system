create view enabled_roles(role_name) as
SELECT rolname::information_schema.sql_identifier AS role_name
FROM pg_authid a
WHERE pg_has_role(oid, 'USAGE'::text);

alter table enabled_roles
    owner to postgres;

grant select on enabled_roles to public;

